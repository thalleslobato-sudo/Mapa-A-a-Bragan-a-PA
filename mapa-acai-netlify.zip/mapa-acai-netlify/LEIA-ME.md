# Mapa do Açaí — Bragança-PA (versão própria, fora do Claude)

Site estático com banco de dados próprio no Supabase. Qualquer pessoa com o
link abre, vê o mapa, cadastra e edita pontos — sem precisar de conta.
Apagar pontos e mudar título, categorias, etiquetas e camadas (ruas/zona
rural) é só do responsável, que entra com e-mail e senha.

## Arquivos

| Arquivo | Para que serve |
|---|---|
| `index.html` | A plataforma inteira (mapa, filtros, cadastro, PDF e Excel) |
| `config.js` | Onde você cola o endereço e a chave pública do seu Supabase |
| `schema.sql` | Cria a tabela, as permissões (RLS) e os 12 pontos iniciais |
| `dados-iniciais.json` | Os mesmos 12 pontos em JSON puro, caso queira usar outro banco |

---

## Passo 1 — Criar o banco (Supabase, gratuito)

1. Crie uma conta em <https://supabase.com> e clique em **New project**.
2. Dê um nome (ex.: `mapa-acai-braganca`), defina a senha do banco e escolha
   a região **South America (São Paulo)**.
3. Aguarde o projeto ficar pronto (1 a 2 minutos).
4. Vá em **SQL Editor → New query**, cole todo o conteúdo de `schema.sql` e
   clique em **Run**. Deve aparecer "Success". Isso cria a tabela, as regras
   de permissão e já insere os 12 pontos de açaí levantados.

> O plano gratuito do Supabase pausa o banco depois de uma semana sem uso.
> Basta abrir o painel do projeto e clicar em "Restore" para reativar — os
> dados não se perdem.

## Passo 2 — Pegar as chaves e preencher o `config.js`

1. No Supabase, vá em **Project Settings → API**.
2. Copie **Project URL** e a chave **anon public**.
3. Abra `config.js` num editor de texto e cole nos dois campos indicados.

A chave `anon` é pública por natureza — ela fica visível para quem abrir o
site. Quem protege os dados são as regras criadas pelo `schema.sql`.
**Nunca** use aqui a chave `service_role`.

## Passo 3 — Criar o seu acesso de responsável

1. No Supabase, vá em **Authentication → Users → Add user**, informe seu
   e-mail e uma senha, e marque para confirmar o e-mail automaticamente.
2. Vá em **Authentication → Sign In / Providers → Email** e **desative**
   a opção *Allow new users to sign up*. Sem isso, qualquer visitante
   poderia criar uma conta e ganhar poder de apagar pontos.

No site, o botão **Entrar** (canto dos filtros) é só para você. Visitantes
não precisam dele para cadastrar ou editar pontos.

## Passo 4 — Publicar no Netlify

**Opção A — Netlify Drop (mais rápido, sem conta de Git)**

1. Acesse <https://app.netlify.com/drop>.
2. Faça login (GitHub, Google ou e-mail) se pedir.
3. Arraste a pasta inteira com os 4 arquivos (`index.html`, `config.js`,
   `schema.sql`, `dados-iniciais.json` — os dois últimos não precisam ir
   para o ar, mas não tem problema se forem) para a área de upload.
4. Em segundos o Netlify gera um link do tipo
   `https://algum-nome-aleatorio.netlify.app`. Pronto, o site está no ar.
5. Para um nome melhor: **Site settings → Change site name**.

**Opção B — GitHub + Netlify (recomendado se for mexer no código depois)**

1. Crie um repositório no GitHub (ex.: `mapa-acai-braganca`) e suba os
   arquivos (`index.html` e `config.js` na raiz).
2. No Netlify, clique em **Add new site → Import an existing project**.
3. Conecte sua conta do GitHub e escolha o repositório.
4. Deixe **Build command** e **Publish directory** em branco (é um site
   estático, não precisa compilar nada) — ou, se os arquivos estiverem
   numa subpasta como `site/`, informe essa pasta em *Publish directory*.
5. Clique em **Deploy site**.

Qualquer alteração futura: basta editar os arquivos no repositório e o
Netlify republica sozinho a cada `git push`.

## Passo 5 — Domínio próprio (opcional)

1. Compre um domínio (ex.: em registro.br ou Namecheap).
2. No Netlify: **Site settings → Domain management → Add a domain**.
3. Siga as instruções para apontar o DNS até o Netlify.

---

## Testando

Depois de publicado, confira:

- ✅ O mapa carrega e os 12 pontos aparecem na lista e no mapa
- ✅ Busca e filtros (categoria, bairro, etiqueta, licença, zona) funcionam
- ✅ **Adicionar ponto** funciona sem estar logado
- ✅ **Entrar** com o e-mail/senha criados no Passo 3 libera "Título e
  categorias", "Importar camada" e o botão "Excluir ponto"
- ✅ Baixar PDF e Baixar Excel funcionam
- ✅ Abrir o link em outro celular/computador mostra as mesmas edições
  (confirma que o tempo real está funcionando)

## Se algo não funcionar

- **Mapa em branco / mensagem de configuração ausente**: revise o
  `config.js` — URL e chave coladas certinho, sem espaços extras.
- **"Não foi possível salvar" ao cadastrar ponto**: confira se rodou o
  `schema.sql` inteiro no SQL Editor (a política `cadastro_aberto_pontos`
  precisa existir).
- **Botão Entrar não loga**: confira e-mail/senha no Supabase em
  **Authentication → Users**, e se o usuário está com o e-mail confirmado.
- **Alterações não aparecem para outras pessoas em tempo real**: no SQL
  Editor, rode `alter publication supabase_realtime add table public.docs;`
  de novo — o `schema.sql` já tenta fazer isso, mas alguns projetos antigos
  do Supabase têm a publicação configurada de forma diferente.
